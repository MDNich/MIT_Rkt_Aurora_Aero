﻿# -*- coding: utf-8 -*-
import compolyx
db = compolyx.DB()
db.open( path=u"Z:\\Developer\\MIT_Rkt_Team\\MIT_Rkt_Aurora_Aero\\MIT_Rkt_Aurora_Aero\\finFEA\\wspc_FEA_files\\dp0\\ACP-Pre\\ACP\\ACP-Pre.acph5" )
